package com.example.batchxml;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBatchXmlDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBatchXmlDemoApplication.class, args);
	}

}
