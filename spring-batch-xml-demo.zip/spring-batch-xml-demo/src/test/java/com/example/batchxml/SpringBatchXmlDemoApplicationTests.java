package com.example.batchxml;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchXmlDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
